# Small continuation bundle

Includes the Markdown handoff, both source versions, generated web build, screenshot, guides and sanitized configuration. Historical native installers are omitted to keep uploads small; they are included in the separate Bhaasa-Recovered-Files.zip. Original PDFs and remote Cloud Shell files remain unavailable. The full-export MANIFEST.json/SHA256SUMS are omitted because they describe the larger archive.
