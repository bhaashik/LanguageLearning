# Missing or unavailable material

This is a recovery export, not proof that every file ever generated in the conversation has been retained. All recoverable project assets are inventoried in MANIFEST.json; absent material is not silently replaced.

## Original uploaded PDFs — unavailable

| Original filename | Original reference | Export result |
| --- | --- | --- |
| malayalam_everyday_vocabulary_grammar.pdf | sediment://file_000000005918820887e3fbcb0d36e19f | Download returned “file could not be authorized or resolved”; no local copy found. |
| malayalam_writing_system_guide.pdf | sediment://file_000000001c5c8208a964f8ddde76d4ea | Download returned “file could not be authorized or resolved”; no local copy found. |

The uploads/ directory has this status recorded, not replacement learning documents. Reattach the original PDFs to the next conversation if they are needed.

## Files located only in the user's Google Cloud Shell

These paths were discussed, but their bytes are not available in this workspace:

- ~/Bhaasa-gateway-stable/test-results/gateway/tts.wav
- ~/Bhaasa-gateway-stable/test-results/gateway/asr-test.json
- ~/Bhaasa-gateway-stable/test-results/gateway/ocr-test.json
- ~/Bhaasa-gateway-stable/test-results/gateway/check-asr.mjs
- Earlier /tmp/bhaasa-asr-test.json, /tmp/bhaasa-tts-test.wav and related /tmp diagnostic outputs on that remote machine.

Do not infer that the remote files are still present. Temporary files previously disappeared after Cloud Shell sessions changed. The handoff preserves the known diagnostic outcomes instead of reconstructing original bytes.

## Other unavailable session material

- Most historical assistant responses are not available verbatim. The Markdown handoff includes the available user record and clearly labelled response context.
- Any earlier screenshots, exported progress, private recordings, ZIP backups or transient build outputs not retained in the accessible workspace or public download branches cannot be recovered here. Only one retained local test screenshot was found.
- Previous environment test logs under /tmp were no longer present at export time. Reported test outcomes are preserved in the handoff; new logs have not been fabricated.
- The old name mentioned by the user, Bhaashik-linux-x64.tgz, was not found as a local artifact. The later published Bhaasa-linux-x64.tar.gz v0.7.1 has been recovered instead and retains its real filename/version.

## Intentionally excluded

Provider API keys, gateway access codes, .env/.secret files, signing credentials, browser profiles/storage, account credential directories, Git internals and dependency caches are outside this portable export. Secret names and public project identifiers are retained as configuration context. No deployed setting was changed, and no paid generation call was made to create replacement audio or images.
