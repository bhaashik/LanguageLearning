# Bhaasa recovered files — 13 November 2026

This archive accompanies Bhaasa-Handoff.md. It includes recovered files, not a guarantee of a full historical session archive. Read MISSING_FILES.md before assuming that an original upload, diagnostic recording or prior assistant response is present.

| Location | Contents and provenance |
| --- | --- |
| source/ | 214 tracked files from the unchanged local checkout, commit 61d4e7d81147327b491553f906a0397ce6ed570d, source version 0.7.2. Includes app code, help, language content, tests, graphics/fonts and licenses, feedback Apps Script, deployment templates, platform projects and CI definitions. |
| LanguageLearning-main-129f0ab05c91.zip | Exact public main source at export time, commit 129f0ab05c9115ed62d9b9d586c956143d940ed2. Newer than the local snapshot, kept separate. Not built/tested during this export. |
| web-build/ | Existing generated static dist/ output from the local snapshot. Serve over HTTP(S), not by opening index.html as a file. It is not the latest remote main build. |
| test-results/ | Retained connections-tablet.png test screenshot; fixture data, not a live provider session. |
| packages/linux-downloads/v0.7.1/ | Historical Bhaasa-linux-x64.tar.gz and published SHA256SUMS. |
| packages/windows-downloads/v0.7.1/ | Historical Bhaasa-windows-x64.zip and published SHA256SUMS. |
| packages/android-downloads/v0.7.1/ | Historical Bhaasa-Android-debug.apk and published SHA256SUMS. Debug signed, not a Play Store release. |
| packages/ios-downloads/v0.7.1/ | Historical Bhaasa-iOS-unsigned.xcarchive.zip and published SHA256SUMS. For Apple signing in Xcode; not directly installable. |
| packages/*/README.md | Download branch instructions retrieved from the public repository. |
| environment/ | Sanitized saved draft and startup instructions. Contains names/public identifiers, no credential values. Does not establish publication or applied network changes. |
| metadata/ | Source commit/version, remote archive provenance, package checksum verification and export scope. |
| uploads/ | Status note only: the two original PDF attachments were not recoverable. |
| MANIFEST.json | Inventory with relative path, byte count and SHA-256 of each payload file. |
| SHA256SUMS | Checksums for all payload files plus MANIFEST.json. |

All four historical native packages matched their published checksums. Do not relabel them as v0.7.2 or as containing later gateway UI fixes. If rebuilding, begin from inspected current source and use the platform-specific toolchain.

The source snapshot has no core npm dependencies. For its known local workflow run npm test and npm run build, then npm run dev from source/. The documented environment uses Node.js 24 and Python Playwright 1.62.0 with system Chromium; Firebase Functions targets Node.js 22. Optional native/Realtime/Firebase dependencies have their own lockfiles. See the handoff for fixture-only checks and known limitations.

No provider keys, gateway access token, private environment files, signing keys, browser storage/profiles, Git internals or dependency caches are included. Nothing was published to GitHub or changed in the deployed cloud to produce this export.

To verify an extracted archive, from this directory on Linux run:

```sh
sha256sum -c SHA256SUMS
```

The checksums detect corruption; they do not substitute for application testing or Apple/Google signing/review.
