# Original uploads

The two original Malayalam PDFs could not be resolved by the upload download service. No PDF bytes are included. See ../MISSING_FILES.md for exact filenames, references and the recovery result. Reattach the originals when continuing in another conversation.
